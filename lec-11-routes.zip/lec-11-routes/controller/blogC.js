const Blog = require('../models/Blog'); // Assuming you have a Blog model
const Category = require('../models/Category'); // Assuming you have a Category model

// View all blogs
exports.viewBlogs = async (req, res) => {
    try {
        const { searchBlogs } = req.query;
        const query = searchBlogs
            ? { title: { $regex: searchBlogs, $options: 'i' } }
            : {};
        const blogs = await Blog.find(query).populate('categoryid');
        const page = parseInt(req.query.page) || 1;
        const limit = 5;
        const totalpage = Math.ceil(blogs.length / limit);

        const paginatedBlogs = blogs.slice((page - 1) * limit, page * limit);
        res.render('blogs/viewBlogs', {
            blogData: paginatedBlogs,
            page,
            totalpage,
        });
    } catch (error) {
        res.status(500).send('Error fetching blogs');
    }
};

// Add a new blog
exports.insertBlog = async (req, res) => {
    try {
        const { blogCategoryid, blogTitle, blogDescription } = req.body;
        const newBlog = new Blog({
            categoryid: blogCategoryid,
            title: blogTitle,
            description: blogDescription,
            author: 'Admin', // Replace with dynamic author if applicable
            blogDate: new Date(),
            images: '/path/to/default/image.jpg', // Replace with uploaded file path
        });
        await newBlog.save();
        res.redirect('/Blogs/viewBlogs');
    } catch (error) {
        res.status(500).send('Error adding blog');
    }
};

// Delete a blog
exports.deleteBlog = async (req, res) => {
    try {
        const { id } = req.params;
        await Blog.findByIdAndDelete(id);
        res.redirect('/Blogs/viewBlogs');
    } catch (error) {
        res.status(500).send('Error deleting blog');
    }
};

// Show edit form
exports.editBlogForm = async (req, res) => {
    try {
        const { id } = req.params;
        const blog = await Blog.findById(id).populate('categoryid');
        const categories = await Category.find();
        res.render('blogs/editBlog', { blog, categories });
    } catch (error) {
        res.status(500).send('Error loading edit form');
    }
};

// Update blog
exports.updateBlog = async (req, res) => {
    try {
        const { id } = req.params;
        const { blogCategoryid, blogTitle, blogDescription } = req.body;
        await Blog.findByIdAndUpdate(id, {
            categoryid: blogCategoryid,
            title: blogTitle,
            description: blogDescription,
        });
        res.redirect('/Blogs/viewBlogs');
    } catch (error) {
        res.status(500).send('Error updating blog');
    }
};
