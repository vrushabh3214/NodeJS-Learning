const express = require('express');
const routes = express.Router();
const categoryclr = require('../controller/categoryController')

routes.get('/',categoryclr.addcategory);
routes.post('/insercategoryBlogs',categoryclr.insercategoryBlogs)
routes.get('/viewcategory', categoryclr.viewcategory);
routes.get('/category/delete/:id',categoryclr.delcate)

module.exports = routes